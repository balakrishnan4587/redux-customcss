const path = require('path');
const webpack = require('webpack');
const ExtractTextPlugin = require('extract-text-webpack-plugin');

module.exports = {
	context: path.resolve(__dirname, './app'),
	entry: {
		app: "./app.js"    
	},

	output: {   
		path: __dirname + "/dist",
		filename: "app.js"	
	},
	resolve:{
		modules: [path.resolve(__dirname, "app"), "node_modules"],
		extensions: [".js", ".json", ".jsx"]	
	}, 
	resolveLoader: {
	  moduleExtensions: ['-loader']
	},

	module: {
		rules: [
		  {
			test: /\.(js|jsx)$/,
			exclude: /node_modules/,
			use: [
			  'babel-loader',
			],
		  },
		  {
			test: /\.html$/,
			use: "file-loader?name=[name].[ext]",
		  },
		  { 
			test: /\.css$/, 
			use: ['style-loader','css-loader']  
			//use: ExtractTextPlugin.extract({
			//	fallback:"style-loader",
			//	use:"css-loader"
			//})
		  },
		  {	
			test: /\.eot(\?v=\d+.\d+.\d+)?$/, 
			use: 'file-loader'
		  },
		  {
			test: /\.woff(2)?(\?v=[0-9]\.[0-9]\.[0-9])?$/, 
			use: "url-loader?limit=10000&mimetype=application/font-woff"
		  },
		  {
			test: /\.ttf(\?v=\d+\.\d+\.\d+)?$/, 
			use: 'url-loader?limit=10000&mimetype=application/octet-stream'
		  },
		  {
			test: /\.svg(\?v=\d+\.\d+\.\d+)?$/, 
			use: 'url-loader?limit=10000&mimetype=image/svg+xml'
		  },
		  {	
			test: /\.(jpe?g|png|gif)$/i, 
			use: 'file-loader?name=[name].[ext]'
		  }
		  
		],
	},
  
	devServer: {
	  open: false, // to open the local server in browser
	  contentBase: __dirname + '/app',
	  hot: true
	},
	
	plugins: [
        new webpack.HotModuleReplacementPlugin(),
		//new ExtractTextPlugin("styles.css"),
        new webpack.DefinePlugin({
           "ENV":JSON.stringify("development"),
		   "process.env": {
				"ENV":JSON.stringify("development"),
                "NODE_ENV": JSON.stringify(process.env.NODE_ENV)
            }
        })		
    ]
}


