import React from 'react';
import { connect } from 'react-redux';
import * as bookActions from '../../actions/bookActions';

class ViewBooks extends React.Component{
  constructor(props){
    super(props);
  }

  submitBook(input){
    this.props.createBook(input);
  }

  render(){
    let titleInput, priceInput=null;
	
    return(
      <div>
        
        <ul>
          {this.props.books.map((b, i) => <li key={i}>{b.title}{b.price}</li> )}
        </ul>
        <div>
          <h3>View Books</h3>
         
        </div>
      </div>
    )
  }
}

// Maps state from store to props
const mapStateToProps = (state, ownProps) => {
  return {
    // You can now say this.props.books
    books: state.booksObj
  }
};

// Maps actions to props
const mapDispatchToProps = (dispatch) => {
  return {
  // You can now say this.props.createBook
    createBook: book => dispatch(bookActions.createBook(book))
  }
};

// Use connect to put them together
export default connect(mapStateToProps, mapDispatchToProps)(ViewBooks);