import React from 'react';
require('./Footer.css');


export default class Footer extends React.Component{

 render(){
	return (

		<div className="footer">Lorem</div>
	  
	);
}


};

